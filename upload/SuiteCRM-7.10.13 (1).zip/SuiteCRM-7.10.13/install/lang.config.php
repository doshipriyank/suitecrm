<?php 

// ADDITIONAL LANGUAGES
$config['languages'] = array(
);
