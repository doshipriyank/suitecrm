<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.10.13';
$suitecrm_timestamp    = '2019-01-31-17:00:00';
