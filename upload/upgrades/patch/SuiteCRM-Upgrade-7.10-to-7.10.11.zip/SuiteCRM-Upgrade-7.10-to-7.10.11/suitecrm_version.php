<?php
if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$suitecrm_version      = '7.10.11';
$suitecrm_timestamp    = '2018-12-05-17:00:00';
